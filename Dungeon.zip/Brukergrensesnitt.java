public interface Brukergrensesnitt{

  public void giStatus(String status);

  public int beOmKommando(String spoersmaal, String[] alternativer);

}
