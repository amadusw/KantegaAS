public interface Godkjenningsfritak{

  public int hentKontrollID();


}

//interface som har metode som retunerer kontrollID
