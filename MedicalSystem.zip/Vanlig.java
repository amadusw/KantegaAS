//lager vanlig som arver fra legemiddel
class Vanlig extends Legemiddel{

//lager kontruktor som sender verdieene til super konstruktoren
  public Vanlig(String n, double p, double v){
    super(n,p,v);
  }


}
